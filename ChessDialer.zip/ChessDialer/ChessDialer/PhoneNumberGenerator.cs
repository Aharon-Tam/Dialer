﻿namespace ChessDialer
{
  using System.Collections.Generic;
  using System.Linq;
  using System.Text;

  using ChessDialer.ChessPieces;
  using ChessDialer.Extensions;
  using ChessDialer.Rules;

  public class PhoneNumberGenerator
  {
    private KeypadBoard keypad;

    private List<IRule> rules;
    private int totalDigits;

    private List<List<PadBox>>[] dialerSets;

    private List<List<PadBox>> finalSet;

    public PhoneNumberGenerator(KeypadBoard keypad, List<IRule> rules, int totalDigits)
    {
      this.keypad = keypad;
      this.rules = rules;
      this.totalDigits = totalDigits;
    }

    public int GeneratePhoneNumbers(Piece chessPiece, (int X, int Y) startLoc)
    {
      var startBox = keypad.Boxes[startLoc.X, startLoc.Y];

      var startList = new List<PadBox>();
      startList.Add(startBox);
      if (!startList.IsLegitSet(rules)) return 0;

      dialerSets = new List<List<PadBox>>[totalDigits];
      for (var iDigit = 0; iDigit < totalDigits; iDigit++)
      {
        dialerSets[iDigit] = new List<List<PadBox>>();
      }

      dialerSets[0].Add(startList);

      for (var iDigit = 1; iDigit < totalDigits; iDigit++)
      {
        var currentLevelList = dialerSets[iDigit - 1];

        foreach (var boxSublist in currentLevelList)
        {
            GetNextNumberFromBox(chessPiece, boxSublist, iDigit);
        }
      }

      finalSet = dialerSets[totalDigits - 1].Where(x => x.Count == totalDigits).ToList();

      return finalSet.Count();
    }

    public List<string> GetAllThePhoneNumbers()
    {
      var numbers = new List<string>();
      foreach (var currentSet in finalSet)
      {
        var sb = new StringBuilder();
        foreach (var padBox in currentSet)
        {
          sb.Append(padBox.Face);
        }

        numbers.Add(sb.ToString());
      }
      return numbers;
    }

    public bool Exists(string number)
    {
      foreach (var currentSet in finalSet)
      {
        var sb = new StringBuilder();
        foreach (var padBox in currentSet)
        {
          sb.Append(padBox.Face);
        }

        var phoneNumber = sb.ToString();

        if (phoneNumber.Equals(number)) return true;
      }

      return false;
    }

    private void GetNextNumberFromBox(Piece chessPiece, List<PadBox> soFarList, int forPosition)
    {
      var nn = keypad.N;
      var mm = keypad.M;

      var iDigit = forPosition;

      var lastBox = soFarList.Last();

      var xyMoves = chessPiece.PossibleMoves;
      var multipleMoves = chessPiece.CanDoMultipleMoves;

      for (var jMove = 0; jMove < xyMoves.Length; jMove++)
      {
        var xMove = xyMoves[jMove].X;
        var yMove = xyMoves[jMove].Y;

        var startX = lastBox.X;
        var startY = lastBox.Y;

        var firstCheck = true;

        while (firstCheck || multipleMoves)
        {
          firstCheck = false;

          var x = startX + xMove;
          var y = startY + yMove;

          var coordinatesAreValid = x >= 0 && y >= 0 && x < nn && y < mm;
          if (!coordinatesAreValid) break;

          var updatedBoxList = new List<PadBox>();
          updatedBoxList.AddRange(soFarList);

          var nextBox = keypad.Boxes[x, y];
          updatedBoxList.Add(nextBox);

          if (updatedBoxList.IsLegitSet(rules))
          {
            dialerSets[iDigit].Add(updatedBoxList);
          }

          startX = x;
          startY = y;
        }
      }
    }
  }
}
