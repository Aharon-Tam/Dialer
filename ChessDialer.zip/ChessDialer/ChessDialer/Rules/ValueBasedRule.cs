﻿namespace ChessDialer.Rules
{
  using System;
  using System.Collections.Generic;

  public class ValueBasedRule : IRule
  {
    private Func<List<PadBox>, bool> func;

    public ValueBasedRule(Func<List<PadBox>, bool> func)
    {
      this.func = func;
    }

    public bool Complied(List<PadBox> input)
    {
      if (func == null) return true;
      return func.Invoke(input);
    }
  }
}
