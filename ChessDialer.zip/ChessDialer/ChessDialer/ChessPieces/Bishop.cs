﻿namespace ChessDialer.ChessPieces
{
  public class Bishop : Piece
  {
    public sealed override (int X, int Y)[] PossibleMoves { get; set; }

    public override bool CanDoMultipleMoves { get; set; } = true;

    public Bishop()
    {
      PossibleMoves = new[] { (-1, -1), (-1, 1), (1, -1), (1, 1) };
    }

    public override string ToString()
    {
      return "Bishop";
    }
  }
}
