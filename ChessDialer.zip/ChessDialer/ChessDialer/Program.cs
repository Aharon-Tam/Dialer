﻿using System;

namespace ChessDialer
{
  using System.Collections.Generic;
  using System.Linq;

  using ChessDialer.ChessPieces;
  using ChessDialer.Rules;

  internal class Program
  {
    static void Main(string[] args)
    {
      // create the keypad
      var keypad = new KeypadBoard(4, 3, "1, 2, 3, 4, 5, 6, 7, 8, 9, *, 0, #");

      // Using here a very simple a custom rule set.
      // each rule contains a Func that acts on the list of Pad's from which a phone number is being generated
      // a production grade version would required the use of something like FluentValidation with Expression types being read from DB
      // or config file.

      Func<List<PadBox>, bool> valueRuleFunc = list =>
        {
          if (list != null && list.Any(x => x.Face.StartsWith("*") || x.Face.StartsWith("#"))) return false;
          return true;
        };

      var valueRule = new PositionRule(valueRuleFunc);

      Func<List<PadBox>, bool> startWithRuleFunc = list =>
        {
          if (list == null || list.Count == 0) return true;

          if (list[0].Face.Equals("0")) return false;

          if (list[0].Face.Equals("1")) return false;

          return true;
        };

      var startWithRule = new ValueBasedRule(startWithRuleFunc);

      var ruleSet = new List<IRule> { valueRule, startWithRule };

      var numberOfDigits = 7;

      // create the generator
      var generator = new PhoneNumberGenerator(keypad, ruleSet, numberOfDigits);

      // generate the number assuming:
      // 1. the piece must move at least once so the phone number cannot have the same number 7-times due not moving
      // 2. the piece can move back and forth between cells/pad-boxes according to the permissible moves.
      // 3. all numbers are generated from a predefine starting location, for a specific given chess-piece
      
      var startLocation = (0, 2);
      var rook = new Rook();

      var count = generator.GeneratePhoneNumbers(rook, startLocation);

      Console.WriteLine($"The {rook} piece that starts at {startLocation}, Generates Total of {count} Phone Numbers");

      // this is a very simple test for now (unit test will be much better and much thorough).
      var testNumber = "3213214";
      var exists1 = generator.Exists(testNumber);
      var existMsg = exists1 ? "exists" : "doesn't exist";

      Console.WriteLine($"{testNumber} {existMsg}");

      Console.ReadKey();
    }
  }
}
