﻿namespace ChessDialer.ChessPieces
{
  public class Knight : Piece
  {
    public sealed override (int X, int Y)[] PossibleMoves { get; set; }

    public override bool CanDoMultipleMoves { get; set; } = false;

    public Knight()
    {
      PossibleMoves = new[] { (2, 1), (2, -1), (1, 2), (1, -2), (-1, 2), (-1, -2), (-2, 1), (-2, -1) };
    }

    public override string ToString()
    {
      return "Knight";
    }
  }
}
