﻿namespace ChessDialer.ChessPieces
{
  public class WhitePawn : Piece
  {
    public sealed override (int X, int Y)[] PossibleMoves { get; set; }

    public override bool CanDoMultipleMoves { get; set; } = false;

    public WhitePawn()
    {
      PossibleMoves = new[] { (0, 1) };
    }

    public override string ToString()
    {
      return "White Pawn";
    }
  }
}
