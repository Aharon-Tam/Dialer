﻿namespace ChessDialer.Rules
{
  using System;
  using System.Collections.Generic;

  public class PositionRule : IRule
  {
    private Func<List<PadBox>, bool> func;

    public PositionRule(Func<List<PadBox>, bool> func)
    {
      this.func = func;
    }

    public bool Complied(List<PadBox> input)
    {
      if (func == null) return true;
      return func.Invoke(input);
    }
  }
}
