﻿namespace ChessDialer.ChessPieces
{
  public abstract class Piece
  {
    public abstract (int X, int Y)[] PossibleMoves { get; set; }

    public abstract bool CanDoMultipleMoves { get; set; }
  }
}
