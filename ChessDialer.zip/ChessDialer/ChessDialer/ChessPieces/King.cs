﻿namespace ChessDialer.ChessPieces
{
  public class King : Piece
  {
    public sealed override (int X, int Y)[] PossibleMoves { get; set; }

    public override bool CanDoMultipleMoves { get; set; } = false;

    public King()
    {
      PossibleMoves = new[] { (-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1) };
    }

    public override string ToString()
    {
      return "King";
    }
  }
}
