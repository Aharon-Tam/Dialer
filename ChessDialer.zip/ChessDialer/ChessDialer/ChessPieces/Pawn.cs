﻿namespace ChessDialer.ChessPieces
{
  public class Pawn : Piece
  {
    public sealed override (int X, int Y)[] PossibleMoves { get; set; }

    public override bool CanDoMultipleMoves { get; set; } = false;

    public Pawn()
    {
      PossibleMoves = new[] { (0, 1) };
    }

    public override string ToString()
    {
      return "Pawn";
    }
  }
}
