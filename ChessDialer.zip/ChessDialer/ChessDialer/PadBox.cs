﻿namespace ChessDialer
{
  /// <summary>
  /// PadBox or Spot represents one block of the keypad grid.
  /// </summary>
  public class PadBox
  {
    public PadBox(int x, int y, string face)
    {
      Face = face;
      X = x;
      Y = y;
    }

    public string Face { set; get; }
    public int X { set; get; }
    public int Y { set; get; }

    public override string ToString()
    {
      return $"[{X},{Y}]|{Face}";
    }
  }
}
