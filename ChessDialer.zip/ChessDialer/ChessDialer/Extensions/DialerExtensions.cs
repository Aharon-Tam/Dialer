﻿namespace ChessDialer.Extensions
{
  using System.Collections.Generic;

  using ChessDialer.Rules;

  public static class DialerExtensions
  {
    public static bool IsLegitSet(this List<PadBox> input, List<IRule> rules)
    {
      if (rules == null || rules.Count == 0) return true;

      foreach (var rule in rules)
      {
        if (!rule.Complied(input)) return false;
      }

      return true;
    }
  }
}
