﻿namespace ChessDialer.ChessPieces
{
  public class Queen : Piece
  {
    public sealed override (int X, int Y)[] PossibleMoves { get; set; }

    public override bool CanDoMultipleMoves { get; set; } = true;

    public Queen()
    {
      PossibleMoves = new[] { (-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1) };
    }

    public override string ToString()
    {
      return "Queen";
    }
  }
}
