﻿namespace ChessDialer.ChessPieces
{
  public class Rook : Piece
  {
    public sealed override (int X, int Y)[] PossibleMoves { get; set; }

    public override bool CanDoMultipleMoves { get; set; } = true;

    public Rook()
    {
      PossibleMoves = new[] { (-1, 0), (1, 0), (0, -1), (0, 1) };
    }

    public override string ToString()
    {
      return "Rook";
    }
  }
}
