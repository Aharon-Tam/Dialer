﻿namespace ChessDialer
{
  using System;

  public class KeypadBoard
  {
    public PadBox[,] Boxes { get; set; }
    public int N { get; set; }
    public int M { get; set; }

    public KeypadBoard(int nn, int mm, string padSet)
    {
      N = nn;
      M = mm;

      var parts = padSet.Split(new [] { ',', ' ', ';', '|' }, StringSplitOptions.RemoveEmptyEntries);

      Boxes = new PadBox[nn, mm];

      for (int i = 0; i < nn; i++)
      {
        for (int j = 0; j < mm; j++)
        {
          var k = i * (nn-1) + j;
          var face = string.Empty;
          if (k < parts.Length)
          {
            face = parts[k];
          }

          Boxes[i, j] = new PadBox(i,j, face);
        }
      }
    }
  }
}
