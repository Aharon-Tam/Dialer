﻿namespace ChessDialer.Rules
{
  using System.Collections.Generic;

  public interface IRule
  {
    bool Complied(List<PadBox> input);
  }
}
